from typing import Optional, Tuple

def snap_to_zone(x: float, y: float) -> Optional[str]:
    # stub: no futuro, use polígonos. Por ora, None
    return None

def snap_to_spot(x: float, y: float) -> Optional[str]:
    # stub: idem
    return None
